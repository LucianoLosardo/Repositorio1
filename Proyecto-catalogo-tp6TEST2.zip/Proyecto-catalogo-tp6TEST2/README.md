# Proyecto-catalogo
TPE programación web, catálogo digital.
Para acceder a la pagina poner en su navegador la URL: http://localhost:8080
Para correr la página junto con la base de datos:
1. Dar permiso de ejecucion al archivo runtest.sh (chmod +x runtest.sh)
2. ejecutar ./runtest.sh 

